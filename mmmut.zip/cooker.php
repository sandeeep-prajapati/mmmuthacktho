<?php
require "server/connection.php";
session_start();
$email = $_SESSION['email'];
if (($_SERVER["REQUEST_METHOD"] == "GET")&&(isset($_SESSION['email']))) {
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- CSS only -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
    <title>Student Login</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container register register-background custBack">
        <div class="row ">
            <div class="col-md-3 register-left">
                <img src="img/red-rocket-png-5.png" alt="">
                <h2 class="text-white">Add Product in your shop</h2>
                <p class="text-white">it will show what are you selling in MMMUT</p>
                <a href="shopCanteen.php"><input type="submit" class="btn btn-xll btn-success" value="Your shop"></a>
            </div>
            <div class="col-md-9 my-5 register-right">
                <form action="cookerUpload.php" method="post" enctype="multipart/form-data">
                    <Label class="p-1 text-white">ENTER PRODUCT TITLE</Label>
                    <br>
                    <input class="input-type p-2" type="text" name="title" placeholder="TITLE OF YOUR PRODUCT" required>
                    <br>
                    <br>
                    <Label class="p-1 text-white">DISCRIPTION</Label>
                    <br>
                    <textarea row = "10" class="input-type p-2" type="text" name="discription" placeholder="Discription" required></textarea>
                    <br>
                    <br>
                    <Label class="p-1 text-white">ENTER PRODUCT PRICE</Label>
                    <br>
                    <input class="input-type p-2" type="number" name="price" placeholder="price" required>
                    <br>
                    <br>
                    <Label class="p-1 text-white">ENTER TYPE OF PRODUCT</Label>
                    <br>
                    <select class="input-type p-2" name="type" placeholder="Email Id " required>
                        <option value="snack">Snack</option>
                        <option value="drink">Drink</option>
                        <option value="milk">Milk</option>
                    </select>
                    <br>
                    <br>
                    <Label class="p-1 text-white">Upload Image</Label>
                    <br>
                    <input class="input-type p-2" type="file" name="f_img" placeholder="Upload" required>
                    <br>
                    <br>
                    <input class="input-button bg-success p-2 text-white btn" type="submit" value="Add Now">
                </form>
            </div>
        </div>
    </div>


        <!-- footer -->
    

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-u1OknCvxWvY5kfmNBILK2hRnQC3Pr17a+RTT6rIHI7NnikvbZlHgTPOOmMi466C8" crossorigin="anonymous">
    </script>
</body>
<?php
}
?>
</html>