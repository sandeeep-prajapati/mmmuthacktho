<nav>
                    <ul>
                        <li>
                            <a href="#" class="logo">
                                <img src="img\teamLogo.png" alt="team logo">
                                <span class="myNav-item">Tech Pantheres</span>
                            </a>
                        </li>
                        <li>
                            <a href="dashboard.php">
                                <i class="fas fa-home">
                                </i>
                                <span class="myNav-item">Home</span>
                            </a>
                        </li>
                        <li>
                            <a href="dashboard2.php">
                                <i class="fas fa-wallet">
                                </i>
                                <span class="myNav-item">Snacks</span>
                            </a>
                        </li>
                        <li>
                            <a href="dashboard3.php">
                                <i class="fas fa-chart-bar">
                                </i>
                                <span class="myNav-item">Drinks</span>
                            </a>
                        </li>
                        <li>
                            <a href="dashboard4.php">
                                <i class="fas fa-tasks">
                                </i>
                                <span class="myNav-item">Milk</span>
                            </a>
                        </li>           
                        <li>    
                            <a href="dashboard5.php?title=&price=">
                                <i class="fas fa-cog">
                                </i>
                                <span class="myNav-item">Orders</span>
                            </a>
                        </li>
                        <li>
                            <a href="dashboard6.php">
                                <i class="fas fa-question-circle">
                                </i>
                                <span class="myNav-item">Complain</span>
                            </a>
                        </li>
                        <li>
                            <a href="logout.php" class="logout">
                                <i class="fas fa-sign-out-alt">
                                </i>
                                <span class="myNav-item">Log Out</span>
                            </a>
                        </li>
                    </ul>
                </nav>