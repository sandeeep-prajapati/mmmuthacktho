
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- CSS only -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
    <title>Student Login</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

    <!-- navBar start -->
    <!-- <div class="container-fluid mt-2">
        <nav class="navbar navbar-expand-lg bg-dark flex-top shadow-lg" style="border-radius: 5px;">
            <div class="container">
                <a class="navbar-brand" href="index.php"><span class="text-warning">MMM</span>University</a>
                <button class="navbar-toggler bg-white" type="button" data-bs-toggle="collapse"
                    data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                    aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
    
                        <li class="nav-item">
                            <a class="nav-link" href="index.php">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="merchant.php">Notics Board</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="merchant.php">Mesh menu</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </div> -->

    <!-- navBar ends -->
    

    
    <div class="container register register-background custBack">
        <div class="row ">
            <div class="col-md-3 register-left">
                <img src="img/red-rocket-png-5.png" alt="">
                <h2 class="text-white">Happy to see you again</h2>
                <p class="text-white">if you are new here start with register your self first...</p>
                <a href="studentRegister.html">
                    <a href="registration.php"><input type="submit" class="btn btn-xll btn-success" value="Register yourself Here"></a>
                </a>
            </div>
            <div class="col-md-9 my-5 register-right">
                <form action="server/loginvalidation.php" method="post">
                    <Label class="p-1 text-white">ENTER YOUR EMAIL ID</Label>
                    <br>
                    <input class="input-type p-2" type="email" name="email" placeholder="Email Id " required>
                    <br>
                    <br>
                    <Label class="p-1 text-white">PASSWORD</Label>
                    <br>
                    <input class="input-type p-2" type="password" name="password" placeholder="PASSWORD" required>
                    <br>
                    <br>
                    <input class="input-button bg-success p-2 text-white btn" type="submit" value="Login Now">
                </form>
            </div>
        </div>
    </div>


        <!-- footer -->
    

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-u1OknCvxWvY5kfmNBILK2hRnQC3Pr17a+RTT6rIHI7NnikvbZlHgTPOOmMi466C8" crossorigin="anonymous">
    </script>
</body>
</html>