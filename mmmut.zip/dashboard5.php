<?php
require "server/connection.php";
session_start();
if (($_SERVER["REQUEST_METHOD"] == "GET")&&(isset($_SESSION['email']))) {
    $title = $_GET["title"];
    $price = $_GET["price"];
    $email = $_GET["email"];
}
else{

}
if ($title != null) {
    $sql = "SELECT title FROM orders WHERE (title='$title')and(email='$email');";
    $res = mysqli_query($conn, $sql);
    $row = mysqli_num_rows($res);
    if ($row == 0) {
        $sql = "SELECT * FROM users WHERE email='$email';";
        $myres = mysqli_query($conn, $sql);
        $newres = mysqli_fetch_array($myres);
        $room = $newres['roomno'];
        $mobile = $newres['contact'];
        $name = $newres['fname'];
        $sql = "INSERT INTO `orders` (`id`, `title`, `price`, `email`, `status`, `roomNo`, `mobile`, `name`) VALUES (NULL, '$title', '$price', '$email', 'waiting', '$room', '$mobile', '$name');";
        $new2res = mysqli_query($conn, $sql);
        if ($new2res) {
            echo "<script>alert('you have ordered it successfully');</script>";
        }

    } else {
        echo "<script>alert('You have already ordered it');</script>";
    }
}
else{
    
}
if (isset($_SESSION['email'])) {
?>
<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet"
            integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"
            integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous">
        </script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css"
            integrity="sha512-MV7K8+y+gLIBoVD59lQIYicR65iaqukzvf/nwasF0nqhPay5w/9lJmVM2hMDcnK1OnMGCdVK+iQrJ7lzPJQd1w=="
            crossorigin="anonymous" referrerpolicy="no-referrer" />
        <script src="dboard.js"></script>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="dashboardDesign.css">
        <title>dashboard</title>
    </head>

    <body>
        <div class="container-fluid">
            <div class="row">
                <div class="lbody">
                <?php
                include "navbar.php";
                ?>
                </div>
                <div class="rbody">
                    <div class="row">
                        <table class="table bg-white m-3">
                            <thead>
                                <tr>
                                    <th scope="col">NAME</th>
                                    <th scope="col">ROOM NO</th>
                                    <th scope="col">TITLE</th>
                                    <th scope="col">PRICE</th>
                                    <th scope="col">MOBILE NO</th>
                                    <th scope="col">STATUS</th>
                                    <th scope="col">ACTION</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php
                                    $sql = "SELECT * FROM orders WHERE email='$email';";
                                    $myres = mysqli_query($conn, $sql);
                            while ($result = mysqli_fetch_array($myres)) {
                                ?>
                                <tr>
                                    <th scope="row"><?php echo $result['name']; ?></th>
                                    <td><?php echo $result['roomNo']; ?></td>
                                    <td><?php echo $result['title']; ?></td>
                                    <td><?php echo $result['price']; ?></td>
                                    <td><?php echo $result['mobile']; ?></td>
                                    <td><?php echo $result['status']; ?></td>
                                    <td><button class="col-md-6 p-1 text-white bg-success"><a href="cancelProduct.php">Cancel Order</a></button><button class="col-md-6 p-1 text-white bg-danger"><a href="delevered.php">Delevered</a></button></td>
                                </tr>
                            <?php
                            }
                            ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </div>

    </body>

    </html>
<?php
}

    else{
    header("Location: registration.php");
}

?>
