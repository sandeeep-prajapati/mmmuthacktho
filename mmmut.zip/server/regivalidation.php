<!-- CREATE TABLE `user`.`localuser` ( `fname` TEXT NOT NULL , `lname` TEXT NOT NULL , `mobilNo` INT(10) NOT NULL , `adress` VARCHAR(30) NOT NULL ) ENGINE = InnoDB;
ALTER TABLE `localuser` ADD `id` INT(10) NOT NULL AUTO_INCREMENT AFTER `adress`, ADD PRIMARY KEY (`id`); -->
<?php
include "connection.php";


if($_SERVER["REQUEST_METHOD"] == "POST") 
{
    $contact = $_POST["contact"];
    $email = $_POST["email"];
    $sql="SELECT fname FROM users WHERE contact='$contact';";
    $res=mysqli_query($conn,$sql);
    $row=mysqli_num_rows($res);
    if($row==0){
        $sql="SELECT fname FROM users WHERE email='$email';";
        $res=mysqli_query($conn,$sql);
        $row=mysqli_num_rows($res);
        if($row==0){
            $fname = $_POST["fname"];
            $lname = $_POST["lname"];
            $rnumber = $_POST["rnumber"];
            $hostel = $_POST["hostel"];
            $password = $_POST["password"];
            
            
            $sql="INSERT INTO `users` (`fname`, `lname`, `contact`, `roomno`, `hostal`, `email`, `password`, `addon`) VALUES ('$fname','$lname','$contact','$rnumber','$hostel','$email','$password',now());";
            $res=mysqli_query($conn,$sql);
            if($res){
                echo "<script>alert('Registred Successfully..');window.location.href='dashboard.php';</script>";
                session_start();
                $_SESSION['email'] = $email;
                header("Location: ../dashboard.php");
            }
            else{
                echo "<script>alert('Sorry Some Error.');window.location.href='../cooker.php';</script>";
            }
        }
        else{
            echo "<script>alert('Email Already Exists.');window.location.href='../registration.php';</script>";
        }
    }
    else{
        echo "<script>alert('Contact Already Exists.');window.location.href='../registration.php';</script>";
    }
}   
else{

    echo "scr";
}

?>