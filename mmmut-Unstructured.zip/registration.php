
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <!-- CSS only -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
        <title>Student Login</title>
        <link rel="stylesheet" href="style.css">
    </head>
    <body>    
    <div class="container register register-background custBack">
        <div class="row ">
            <div class="col-md-3 register-left">
                <img src="img/red-rocket-png-5.png" alt="">
                <h2 class="text-white">Welcome</h2>
                <p class="text-white">Hi please share your details to utilize our services.......</p>
                    <a href="login.php"><input type="submit" class="btn btn-xll btn-success" value="Login yourself Here"></a>
            </div>
            <div class="col-md-9 my-5 register-right">
                <form action="regivalidation.php" method="post">
                    <Label class="p-1 text-white">ENTER YOUR First Name</Label>
                    <br>
                    <input class="input-type p-2" type="text" name="fname" placeholder="First name" required>
                    <br>
                    <Label class="p-1 text-white">ENTER YOUR Last Name</Label>
                    <br>
                    <input class="input-type p-2" type="text" name="lname" placeholder="Last Name" required>
                    <br>
                    <Label class="p-1 text-white">ENTER YOUR Contact No</Label>
                    <br>
                    <input class="input-type p-2" type="number" name="contact" placeholder="Contact No....." required>
                    <br>
                    <Label class="p-1 text-white">ENTER YOUR Room No</Label>
                    <br>
                    <input class="input-type p-2" type="number" name="rnumber" placeholder="Room Number" required>
                    <br>
                    <Label class="p-1 text-white">ENTER YOUR Hostel Type</Label>
                    <br>
                    <select name="hostel" class="input-type p-2" id="">
                        <option value="Boys Hostel">Boys Hostel</option>
                        <option value="Girls Hostel">Girls Hostel</option>
                    </select>
                    <br>
                    
                    <Label class="p-1 text-white">ENTER YOUR EMAIL ID</Label>
                    <br>
                    <input class="input-type p-2" type="email" name="email" placeholder="Email Id " required>
                    <br>
                    <Label class="p-1 text-white">PASSWORD</Label>
                    <br>
                    <input class="input-type p-2" type="password" name="password" placeholder="PASSWORD" required>
                    <br>
                    <br>
                    <input class="input-button bg-success p-2 text-white btn" type="submit" value="Register Now">
                </form>
            </div>
        </div>
    </div>


        <!-- footer -->
    

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-u1OknCvxWvY5kfmNBILK2hRnQC3Pr17a+RTT6rIHI7NnikvbZlHgTPOOmMi466C8" crossorigin="anonymous">
    </script>
</body>
</html>