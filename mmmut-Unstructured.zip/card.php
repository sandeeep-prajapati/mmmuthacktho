<div class="row">
    <!-- <div class="col-sm-12"> -->
    <?php
    while($result = mysqli_fetch_array($qury))
    {
    ?>
    <div class="col-md-3 col-sm-6 p-3">
        <div class="card">
            <img src="<?php echo $result['file']; ?>" class="card-img-top" alt="card img">
            <div class="card-body">
                <h5 class="card-title"><?php echo $result['title']; ?></h5>
                <p class="card-text"><?php echo $result['discription']; ?></p>
            </div>
            <ul class="list-group list-group-flush">
                <li class="list-group-item">Rs <?php echo $result['price']; ?></li>
                <li class="list-group-item"><?php echo $result['type']; ?></li>
            </ul>
            <div class="card-body">
                <div class="col-md-6 bg-success text-white">
                    <a href="dashboard5.php?title=<?php echo $result['title']; ?>&price=<?php echo $result['price']; ?>&type=<?php echo $result['type']; ?>&email=<?php echo $_SESSION['email']?>" class="card-link">Order Now</a>
                </div>
            </div>
        </div>
    </div>
    <?php
    }
    ?>
    <!-- </div> -->
</div>