// var h=document.getElementById("h");
// var s=document.getElementById("s");
// var d=document.getElementById("d");
// var m=document.getElementById("m");
// var o=document.getElementById("o");
// var c=document.getElementById("c");
function home(){
    document.getElementById("s").style.display="none";
    document.getElementById("d").style.display="none";
    document.getElementById("m").style.display="none";
    document.getElementById("o").style.display="none";
    document.getElementById("c").style.display="none";
    document.getElementById("h").style.display="block";
}
function snack(){
    document.getElementById("h").style.display="none";
    document.getElementById("d").style.display="none";
    document.getElementById("m").style.display="none";
    document.getElementById("o").style.display="none";
    document.getElementById("c").style.display="none";
    document.getElementById("s").style.display="block";
}
function drink(){
    document.getElementById("s").style.display="none";
    document.getElementById("h").style.display="none";
    document.getElementById("m").style.display="none";
    document.getElementById("o").style.display="none";
    document.getElementById("c").style.display="none";
    document.getElementById("d").style.display="block";
}
function milk(){
    document.getElementById("s").style.display="none";
    document.getElementById("d").style.display="none";
    document.getElementById("h").style.display="none";
    document.getElementById("o").style.display="none";
    document.getElementById("c").style.display="none";
    document.getElementById("m").style.display="block";
}
function order(){
    document.getElementById("s").style.display="none";
    document.getElementById("d").style.display="none";
    document.getElementById("m").style.display="none";
    document.getElementById("h").style.display="none";
    document.getElementById("c").style.display="none";
    document.getElementById("o").style.display="block";
}
function complain(){
    document.getElementById("s").style.display="none";
    document.getElementById("d").style.display="none";
    document.getElementById("m").style.display="none";
    document.getElementById("o").style.display="none";
    document.getElementById("h").style.display="none";
    document.getElementById("c").style.display="block";
}