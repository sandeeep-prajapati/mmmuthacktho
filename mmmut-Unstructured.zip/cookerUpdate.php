<?php
require "connection.php";
session_start();
if (($_SERVER["REQUEST_METHOD"] == "GET")&&(isset($_SESSION['email']))) {
    $discription = $_GET["discription"];
    $title = $_GET["title"];
    $price = $_GET["price"];
    $email = $_GET["email"];
    ?>
    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet"
            integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"
            integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous">
            </script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css"
            integrity="sha512-MV7K8+y+gLIBoVD59lQIYicR65iaqukzvf/nwasF0nqhPay5w/9lJmVM2hMDcnK1OnMGCdVK+iQrJ7lzPJQd1w=="
            crossorigin="anonymous" referrerpolicy="no-referrer" />
        <script src="dboard.js"></script>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="dashboardDesign.css">
        <link rel="stylesheet" href="style.css">
        <title>Document</title>
    </head>

    <body>
    <div class="container register register-background custBack">
        <div class="row ">
            <div class="col-md-3 register-left">
                <img src="img/red-rocket-png-5.png" alt="">
                <h2 class="text-white">For deleting product</h2>
                <p class="text-white">it will delete this card what are you selling in MMMUT</p>
            </div>
            <div class="col-md-9 my-5 register-right">
            <h2 class="text-warning text-center">For Update</h2>
            
            <form action="cookerUpload.php" method="post" enctype="multipart/form-data">
                    <Label class="p-1 text-white">ENTER PRODUCT TITLE</Label>
                    <br>
                    <input class="input-type p-2" type="text" name="title" placeholder="TITLE OF YOUR PRODUCT" value="<?php echo $title; ?>" required>
                    <br>
                    <br>
                    <Label class="p-1 text-white">DISCRIPTION</Label>
                    <br>
                    <textarea row = "10" class="input-type p-2" type="text" name="discription" placeholder="Discription" required><?php echo $discription; ?></textarea>
                    <br>
                    <br>
                    <Label class="p-1 text-white">ENTER PRODUCT PRICE</Label>
                    <br>
                    <input class="input-type p-2" type="number" name="price" placeholder="price" value="<?php echo $price; ?>" required>
                    <br>
                    <br>
                    <Label class="p-1 text-white">ENTER TYPE OF PRODUCT</Label>
                    <br>
                    <select class="input-type p-2" name="type" placeholder="Email Id " value="<?php echo $type; ?>" required>
                        <option value="snack">Snack</option>
                        <option value="drink">Drink</option>
                        <option value="milk">Milk</option>
                    </select>
                    <br>
                    <br>
                    <Label class="p-1 text-warning">Please pick image again</Label>
                    <br>
                    <input class="input-type p-2" type="file" name="f_img" placeholder="please pick image again" required>
                    <br>
                    <br>
                    <input class="input-button bg-success p-2 text-white btn" type="submit" value="Update Now">
                </form>
            </div>
        </div>
    </div>


    </body>

    </html>
    <?php
} else {
    header("Location: registration.php");
}
?>