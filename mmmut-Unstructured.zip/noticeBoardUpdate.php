<?php
require "connection.php";
session_start();
if (isset($_SESSION['email'])) {
    $select = "SELECT * FROM products;";
    $qury = mysqli_query($conn, $select);
?>



<?php
}
?>