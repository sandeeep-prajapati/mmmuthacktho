<?php
require "connection.php";
session_start();
if(isset($_SESSION['email'])){
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous">
    </script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css"
        integrity="sha512-MV7K8+y+gLIBoVD59lQIYicR65iaqukzvf/nwasF0nqhPay5w/9lJmVM2hMDcnK1OnMGCdVK+iQrJ7lzPJQd1w=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <script src="dboard.js"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="dashboardDesign.css">
    <link rel="stylesheet" href="style.css">
    <title>Document</title>
</head>

<body>
    <div class="container-fluid">
        <div class="row">
            <div class="lbody">
            <?php
                include "navbar.php";
            ?>
            </div>
            <div class="rbody">
            <div class="row" style="width: 100%">
            <div class="col-md-3 register-left">
                <img src="img/red-rocket-png-5.png" alt="">
                <h2 class="text-white">Please tell us</h2>
                <p class="text-white">you can help us to increase user convenies with these datas</p>
            </div>
            <div class="col-md-9 my-5 register-right">
                <form action="complain.php" method="post">
                    <br>
                    <br>
                    <h2 class="text-white aline-center">SORRY FOR INCONVENIENCE EW WILL LIKE TO HERE YOUR ISSUES</h2>
                    <br>
                    <br>
                    <Label class="p-1 text-white">TELL US PROBLEMS</Label>
                    <br>
                    <textarea class="input-type p-2" type="text" row="5" name="problem" placeholder="ENTER YOUR PROBLEM" required></textarea>
                    <br>
                    <br>
                    <input class="input-button bg-success p-2 text-white btn" type="submit" value="Submite Now">
                </form>
            </div>
        </div>
            </div>
        </div>

    </div>

    <!-- <div class="container-fluid">
        <div class="row">
            <div class="col-md-3 col-sm-6">
                <p>hsjgdbh</p>
            </div>
            <div class="col-md-3 col-sm-6">
                <p>hsjgdbh</p>
            </div>
            <div class="col-md-3 col-sm-6">
                <p>hsjgdbh</p>
            </div>
        </div>
    </div> -->




</body>

</html>
<?php
}else{
    header("Location: registration.php");
}
?>