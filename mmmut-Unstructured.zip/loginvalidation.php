<?php
require "connection.php";

if($_SERVER["REQUEST_METHOD"] == "POST") 
{
    $email = $_POST["email"];
    $password = $_POST["password"];
    $re = "SELECT * FROM users WHERE (email = '$email' and  password= '$password');";
    $res = mysqli_query($conn, $re);
    $result = mysqli_fetch_array($res);
    $resultOfPassword = (mysqli_num_rows($res)==1);

    if(($resultOfPassword==true)&&($result['password']==$password))
    {        
        session_start();
        $_SESSION['email'] = $result['email'];
        $_SESSION['id'] = $result['id'];
        header("Location: dashboard.php");
            
    }
    else{
        echo "<script>alert('there are email or password is not valied');</script>";
        header("Location: login.php");
    
    }
}
else{

    echo "scr";
}
?>